function goToPage(name) {
    console.log(`Going to page for ${name}`)
    window.location.href = `./pages/${name}.html`
}