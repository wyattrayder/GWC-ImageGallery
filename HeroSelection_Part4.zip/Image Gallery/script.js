function goToPage(name) {
    console.log(`Going to page for ${name}`);
    window.location.href = `./pages/${name}.html`;
}

// Go back to the index.html location. The "home" page
function goHome() {
    window.location.href = '../index.html';
}